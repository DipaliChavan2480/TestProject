const { defineConfig } = require('cypress')

module.exports = defineConfig({
  projectId: 's8br3i',
  chromeWebSecurity: false,
  viewportHeight: 900,
  viewportWidth: 1440,
  defaultCommandTimeout: 100000,
  pageLoadTimeout: 100000,
  userAgent: 'Tester-Allow',
  reporter: 'cypress-multi-reporters',
  reporterOptions: {
    reporterEnabled: 'cypress-mochawesome-reporter, mocha-junit-reporter',
    mochaJunitReporterReporterOptions: {
      mochaFile: 'cypress/reports/junit/results-[hash].xml',
    },
    cypressMochawesomeReporterReporterOptions: {
      charts: true,
      reportDir: 'cypress/reports/',
      reportPageTitle: 'Testcase',
    },
  },
  retries: {
    runMode: 1,
    openMode: 1,
  },
  env: {
    USER_EMAIL:'',
    USER_PASSWORD:'',
    AUTHORIZATION:'',
    LOGINURL:'',
    CHECK_TOKEN:'',
    QA:'https://testlaunchpad.in/roarsports-qa'
  },
  e2e: {
    setupNodeEvents(on, config) {
      return require('./cypress/plugins/index.js')(on, config)
    },
  },
})

