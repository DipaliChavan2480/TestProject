/* eslint-disable global-require */
/* eslint-disable no-param-reassign */
require('dotenv').config();
const { rmdir } = require('fs');

/**
 * @type {Cypress.PluginConfig}
 */
module.exports = async (on, config) => {
  config.env.USER_EMAIL = process.env.USER_EMAIL;
  config.env.USER_PASSWORD = process.env.USER_PASSWORD;
  config.env.AUTHORIZATION = process.env.AUTHORIZATION;
  config.env.QA = process.env.QA;
  config.env.LOGINURL = process.env.LOGINURL;
  config.env.CHECK_TOKEN = process.env.CHECK_TOKEN;

  on('before:run', async (details) => {
    console.log('override before:run');
    await beforeRunHook(details);
  });
  on('after:run', async () => {
    console.log('override after:run');
    await afterRunHook();
  });
  on('task', {
    deleteDownloads() {
      console.log('Deleting downloads');
      return new Promise((resolve) => {
        rmdir('cypress/downloads', () => {
          resolve(null);
        });
      });
    },
  });
  return config;
};
