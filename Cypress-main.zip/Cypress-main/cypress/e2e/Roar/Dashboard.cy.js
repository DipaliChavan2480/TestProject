describe('Roar login ', () => {
  beforeEach(() => {
    cy.userLogin('/#!/dashboard');
    cy.waitForNetworkResources();
    cy.get('.logo').should('be.visible');
  });
  it('Chek user Email', () => {
    cy.get('.navbar-custom').should('be.visible');
    cy.waitForNetworkResources();
    cy.checkUserEmail();
  });

  it('tab', () => {
    cy.get('.me-2').should('have.text', "Today's Booking");
    cy.get('[ng-reflect-router-link="/booking/upcoming"]').should(
      'have.text',
      'Upcoming Booking'
    );
  });

  it('sideNav', () => {
    cy.get(':nth-child(1) > .side-nav-link')
      .should('be.visible')
      .and('have.text', 'Reports');
    cy.get(
      ':nth-child(1) > .side-nav-link > [src="assets/images/sidebar/arrow-down.svg"]'
    )
      .click()
      .then(() => {
        cy.get(':nth-child(1) > .sub-side-nav-link').should(
          'have.text',
          'Financial'
        );
        cy.get(':nth-child(2) > .sub-side-nav-link').should(
          'have.text',
          'Membership'
        );
      });
    cy.get(':nth-child(2) > .side-nav-link').should('have.text', 'Bookings');
    cy.get(':nth-child(3) > .side-nav-link').should('have.text', 'Facilities');
    cy.get(':nth-child(4) > .side-nav-link').should('have.text', 'Courts');
    cy.get(':nth-child(5) > .side-nav-link').should('have.text', 'Packages');
    cy.get(':nth-child(6) > .side-nav-link').should('have.text', 'Events');
    cy.get(':nth-child(7) > .side-nav-link').should('have.text', 'Services');
    cy.get(':nth-child(7) > .side-nav-link')
      .click()
      .then(() => {
        cy.get(
          ':nth-child(7) > .sub-menu > ul > :nth-child(1) > .sub-side-nav-link'
        ).should('have.text', 'Manage Services');
        cy.get(
          ':nth-child(7) > .sub-menu > ul > :nth-child(2) > .sub-side-nav-link > span'
        ).should('have.text', 'Service Request');
      });
    cy.get(':nth-child(8) > .side-nav-link').should('have.text', 'Membership');
    cy.get(':nth-child(9) > .side-nav-link').should('have.text', 'Payments');
    cy.get(':nth-child(10) > .side-nav-link').should('have.text', 'Customers');
    cy.get(':nth-child(11) > .side-nav-link').should('have.text', 'Employees');
    cy.get(':nth-child(12) > .side-nav-link').should('have.text', 'Inventory');
    cy.get(':nth-child(13) > .side-nav-link').should('have.text', 'Schedule');
    cy.get(
      ':nth-child(13) > .side-nav-link > [src="assets/images/sidebar/arrow-down.svg"]'
    )
      .click()
      .then(() => {
        cy.get(
          ':nth-child(13) > .sub-menu > ul > :nth-child(1) > .sub-side-nav-link'
        ).should('have.text', 'Teams');
        cy.get(
          ':nth-child(13) > .sub-menu > ul > :nth-child(2) > .sub-side-nav-link'
        ).should('have.text', 'Invitation');
        cy.get(
          ':nth-child(13) > .sub-menu > ul > :nth-child(3) > .sub-side-nav-link'
        ).should('have.text', 'Schedule');
      });
    cy.get(':nth-child(14) > .side-nav-link').should('have.text', 'Rating');
  });
});
