Cypress.Commands.add('logOut', () => {
  cy.get('[data-testid="userMenu"]').click({ force: true });
  cy.get('[data-testid="logout-action"]').should('be.visible');
  cy.get('[data-testid="logout-action"]').should('contain.text', 'Logout');
  cy.get('[data-testid="logout-action"]')
    .click({ force: true })
    .then(() => {
      cy.get('[data-testid="customAlertBtn"]').should('be.visible');
      cy.get('[data-testid="customAlertBtn"] > .MuiButton-label').should(
        'contain',
        'Logout'
      );
      cy.get('.MuiDialog-container > .MuiPaper-root').should('be.visible');
      cy.get('[data-testid="customAlertBtn"]').should('be.visible');
      // checking logout alert message with text
      cy.get('.MuiDialog-container > .MuiPaper-root').should(
        'contain',
        'Are you sure you want to logout?'
      );
      // User is successfully logout once click on logout
      cy.get('[data-testid="customAlertBtn"]').click({ force: true });

      // checking URL once logout succesfully
      cy.url().should('include', 'login');
    });
});

// LogOut for POV screen
Cypress.Commands.add('logOutPOV', () => {
  cy.get('.MuiFab-label').click();
  cy.get('.MuiList-root').should('be.visible');
  cy.get('[data-testid="help"]').should('contain', 'Help');
  cy.get('[data-testid="logout-action"]').should('be.visible');
  cy.get('[data-testid="logout-action"]').should('contain', 'Logout');
  cy.get('[data-testid="logout-action"]')
    .click()
    .then(() => {
      cy.get('.MuiDialog-container > .MuiPaper-root').should('be.visible');
      cy.get('[data-testid="customAlertBtn"] > .MuiButton-label').click();

      // checking logout alert message with text
      cy.get('.MuiDialog-container > .MuiPaper-root').should(
        'contain',
        'Are you sure you want to logout?'
      );
      // User is successfully logout once click on logout
      cy.get('[data-testid="customAlertBtn"] > .MuiButton-label').dblclick({
        force: true,
      });

      // checking URL once logout succesfully
      cy.url().should('include', 'login');
    });
});
