/* eslint-disable consistent-return */
import 'cypress-localstorage-commands';

Cypress.Commands.add('login', (email, password) => {
  cy.get('#mat-input-0').should('be.visible');
  cy.get('#mat-input-1').should('be.visible');
  cy.get('#mat-input-0').type(email);
  cy.get('#mat-input-1').type(password);
  cy.get(':nth-child(4) > .mat-focus-indicator').click();
  cy.waitForNetworkResources();
});

Cypress.Commands.add('userLogin', (endpoint) => {
  cy.byPassUILogin(Cypress.env('USER_EMAIL'), Cypress.env('USER_PASSWORD'));
  cy.visitAndLogin(endpoint);
});

Cypress.Commands.add('checkUserEmail', (userEmail) => {
  // Checking User Name as we display in, side nav menu
  cy.get('[src="assets/images/topbar/arrow-down.svg"]').click();
  cy.waitForNetworkResources();
  cy.get('.user-dropdown')
    .should('be.visible')
    .waitForNetworkResources()
    .then(() => {
      cy.get('.user-info').should('be.visible');
      cy.waitForNetworkResources();
      cy.get('.user-info').each(($email) => {
        const email = $email.find('.email').text();
        expect(email).to.equal(Cypress.env('USER_EMAIL'));
        cy.get('.user-avatar > img').click();
      });
    });
});

Cypress.Commands.add("byPassUILogin", (email,password) => {
  cy.request({
    method: "POST",
    url:Cypress.env('LOGINURL'),
    form: true, // Send data as form-urlencoded
    body: {
      grant_type: "password",
      username: email,
      password: password,
    },
    headers: {
      'Authorization': Cypress.env('AUTHORIZATION'),
    },
  }).then((response) => {
    expect(response.status).to.equal(200); 
    expect(response.body.access_token).to.exist;
    const currentUser = JSON.stringify(response.body);
    const accessToken = response.body.access_token;
    cy.setLocalStorage('currentUser', currentUser);
    cy.setLocalStorage('access_token', accessToken);
    cy.request({
      method: 'GET',
      url: Cypress.env('CHECK_TOKEN'),
      qs: {
        token: accessToken,
        access_token: accessToken
      }
    }).then((response) => {
      expect(response.status).to.equal(200);
      var user = response.body.user_name;
      var Currency = JSON.parse(response.body.user_name);
      var Curr = JSON.stringify(Currency.organization.currency);
      var Sub = JSON.stringify(Currency.organization.subscription);
      cy.setLocalStorage('user', user); 
      cy.setLocalStorage('currency', Curr);
      cy.setLocalStorage('subscription', Sub);
    });
  });
});

