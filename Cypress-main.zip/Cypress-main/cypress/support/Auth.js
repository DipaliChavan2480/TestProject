Cypress.Commands.add(
  'visitAndLogin',
  {
    prevSubject: 'optional',
  },
  (subject, url = undefined, userAgent = 'Tester-Allow') => {
    cy.checkEnvironment().then((headers) => {
      const options = {
        log: false,
        headers,
        onBeforeLoad: (win) => {
          Object.defineProperty(win.navigator, 'userAgent', {
            value: userAgent,
          });
        },
      };
      if (subject) {
        cy.visit(subject, options);
      } else {
        cy.visit(url, options);
      }
    });
  }
);
