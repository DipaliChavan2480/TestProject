🐶 Welcome to the Cypress end-to-end tests. 🐶

# Before getting started.

Read through the official getting started docs to acquaint yourself with how Cypress works [Getting started] (https://docs.cypress.io/guides/getting-started/installing-cypress) and the [Core Concepts] (https://docs.cypress.io/guides/core-concepts/introduction-to-cypress).

# Cloning the GitHub Repository.

    $ git clone git@github.com:-------------.git

Navigate to the cypress directory where you cloned the repo. You should be inside the directory that contains the 'package.json' file. To set everything up type the command: 'npm install'. This command should install the required dependencies such as cypress etc.

# Install the dependencies.

If you are using macOS or Windows 10 you should have the node pre-installed. Verify this by typing 'node --version'. You should see that node is installed. If for whatever reason, the node isn't installed you should now install the node.
After installing the node, you may have to restart your computer.

# How to run tests on local.

As the tests are accessing some sensitive APIs you will need to set up a few environment variables. This is because we do not want to commit to the repo these sensitive passwords and keys. Keys can be found in two places in the Development password vault: "cypress.json", "index.js", and ".env file".

1. Copy “.env" file into the root of the customer-portal-tests from following vault
   [.env]().

2. Make sure "cypress.json" is in the root of customer-portal-tests folder [cypress.config.json]. But, if any default configurations can be changed in here later
3. Make sure "index.js" exists at customer-portal-tests/Plugins folder [index.js]. Can be updated with any additional variables if required

# How do I open Cypress.

To open cypress run the following command from the directory that contains the package.json file:
`npm run test`.
As the command suggests this will execute Cypress in the open mode with the test case config After running the command the Cypress test runner should appear.
To instead run Cypress in its "run" mode (headless) do the following command:
`npm run test: run`.

## Linting.

Both prettier and eslint are used for linting and linting rules are provided in the repo.

We also have the following linting commands set up:

```
npm run eslint:check
npm run eslint:fix
npm run prettier:check
npm run prettier:fix

## Setting Up Your Environment variables.

| Environment Variable | Default Value           | Description                                 |
| :--------------------| :---------------------: | :------------------------------------------ |
| USER_EMAIL           | `xyz@gmail.com `        | Email for user having admin role access     |
| USER_PASSWORD        | `Abcd@1234`             | Password for user having admin role access  |
| 
```
